# $Id: install.rb,v 1.3 2001/02/20 22:13:58 andy Exp $ 
#
# Installer for dbc
#
# Copyright (c) 2000 The Pragmatic Programmers, LLC. All Rights Reserved.
# Author: Andrew Hunt (andy@pragmaticprogrammer.com)

require 'rbconfig'
require 'ftools'
include Config


$dest_dir=CONFIG['sitedir'] + "/" + CONFIG['MAJOR'] + "." + CONFIG['MINOR']

def install_file(f)
	begin
		File.install(f, $dest_dir + "/" + f, 0644, true)
	rescue
		$stderr.puts "\n#{$!}\n\nCannot write files. Perhaps try it as `root'?"
		exit 1
	end
end

def uninstall_file(f)
	begin
		File.unlink($dest_dir + "/" + f)
	rescue
		$stderr.puts "\n#{$!}\n\nCannot remove files. Perhaps try it as `root'?"
		exit 1
	end
end

if ARGV[0] =~ /^-un/
	$uninstall = true
else
	$uninstall = false 
end

%w{
	SourceFile.rb
	dbc.rb
}.each {|f|
	if $uninstall
		uninstall_file(f)
	else
		install_file(f)
	end
}

exit 0
