#
# $Id: dbc.rb,v 1.7 2001/02/20 22:13:58 andy Exp $
#
=begin

Design By Contract(tm) for Ruby


Copyright (c) 2000 The Pragmatic Programmers, LLC. All Rights Reserved.
Author: Andrew Hunt (andy@pragmaticprogrammer.com)

=end


require 'SourceFile'

# You may want to make the base class Exception
# or something else instead of StandardError
_DBC_BASE_EXCEPTION=StandardError

# These are the exceptions we can throw
class PreConditionException < _DBC_BASE_EXCEPTION
end

class PostConditionException < _DBC_BASE_EXCEPTION
end

class InvariantException < _DBC_BASE_EXCEPTION
end

class CheckConditionException < _DBC_BASE_EXCEPTION
end


#
# Add basic calls to Object itself.
#
class Object
  #
  # The default invariant is always true.  
  # This allows us to blindly call super from an
  # invariant and know that it will work.
  #
  def invariant
    true
  end
   # Ignore
  def pre(&block) 
  end
  # Ignore
  def post(&block)
  end

  #
  # We establish per-object guards
  # against unwanted re-entrancy
  #
  def _dbc_guard=(x)
    @_dbc_guard = x
  end

  #
  # Order isn't guaranteed, so we may
  # have to initialize the variable
  # on first access.  Also, we may pretend
  # to have a guard up if a particular check
  # is disabled.
  #
  def _dbc_guard(where)
    return true if (where & DbC::Runtime.enabled == 0)
    if !defined? @_dbc_guard
      @_dbc_guard = false
    end
    @_dbc_guard
  end

  #
  # User-level method to check a boolean condition
  #
  def check(str="",&block)
    begin
      ret = block.call
    rescue
      str += $!
      ret = false
    end
    raise(CheckConditionException.exception(str), caller[1]) unless ret
  end

  #
  # User-level method for implications:
  # If the first boolean condition is true, check the second.
  #
  def implies(cond1, cond2)
    if cond1
      cond2
    else
      true
    end
  end
end # End class Object

#
# ---------------------------------------------------------
#
module DbC

#
# Control flag values for various
# levels of checking.
#
class Runtime
  NONE = 0x0
  PRE  = 0x1
  POST = 0x2
  INV  = 0x4
  CHECK= 0x8
end

#
# Main DBC Runtime control Class
#
class Runtime

#####################################################################
# Private Methods
#####################################################################

  private
    @@norecurse = false   # Parsing recursion guard
    @@conditions = {}     # Keep track of methods with pre/post conditions
    @@saves = []          # Save Old Values here
    @@curResult= nil      # Result of current call
    @@invariantList = {}  # List of classes that have invariants
    @@enable = PRE | POST | INV | CHECK

  #
  # Rename a method to the __real form,
  # obeying Ruby naming conventions.
  #
  def Runtime.xform(methodName)
    case methodName
      when /(.*)([\?\!\=])$/ 
        "#{$1}__real#{$2}"
      else
        "#{methodName}__real"
    end
  end

  #
  # Wrap all public instance methods that haven't
  # already been wrapped.
  #
  def Runtime.invariantWrap(klass)

    @@invariantList[klass] = 1
    list = {}

    # Build a list of instance methods into a hash
    klass.public_instance_methods.each{|methodName|
        list[methodName] = 1
    }

    # Now see what we have to do...
    list.each_key {|methodName|
      if (methodName !~ /__real/) &&       # Already wrapped
          (methodName != "check") && 
          (methodName != "implies") && 
          (methodName != "invariant") && 
          (methodName !~ /pre_/) && 
          (methodName !~ /^_dbc/) && 
          (methodName !~ /post_/) && 
          (!list.has_key?(xform(methodName)))
        # 
        # If we need to wrap it and it doesn't
        # have pre/post conditions, just put a simple
        # invariant wrapper around it.
        #
        klass.module_eval <<-EOF
          alias #{xform(methodName)} #{methodName}
          def #{methodName}(*args,&block)
            result = #{xform(methodName)}(*args,&block)
            if !_dbc_guard(INV)
              self._dbc_guard = true
              invariant
              self._dbc_guard = false
            end
            result
          end
        EOF
      end
    }
  end

#####################################################################
# Creation      
#####################################################################
  
#####################################################################
# Command      
#####################################################################
  public

  #
  # User-level control to selectively enable/disable DBC checking
  #
  def Runtime.enable(flags=(PRE | POST | INV | CHECK))
    @@enable = flags
    ObjectSpace.each_object {|x|
      x._dbc_guard = false unless x.frozen?
    }
  end

  #
  # Returns current flags
  #
  def Runtime.enabled
    @@enable
  end

  # Save result of current real call
  def Runtime.result=(res)
      @@curResult= res
  end

  #
  # User-level code: users can call
  # DBC.result in a post-condition to see the 
  # return value for the current call.
  #
  def Runtime.result
      @@curResult
  end

  #
  # Save "old" values for current call
  #
  def Runtime.[]=(index,arg)
    @@saves[index] = arg
  end
  def Runtime.[](index)
    @@saves[index]
  end

  #
  # Keep track of methods with pre/post
  # conditions.  Pass in the Fully Qualified Method name.
  #
  def Runtime.saveCondition(fqm)
    @@conditions[fqm] = 1
  end
  def Runtime.hasCondition(fqm)
    @@conditions.key?(fqm)
  end

  #
  # Returns true if the given Class has
  # a defined invariant method.
  #
  def Runtime.hasInvariant(klass)
    @@invariantList.key?(klass)
  end

  #
  # The main workhorse.  Given a Class, a Symbol for a method,
  # and a file and line of source code, build the needed
  # methods and aliases.
  #
  def Runtime.parse(klass, methodName, fileAndLine)

    # Once at a time is enough, thank you...
    return if @@norecurse

    # You can't have pre/post conditions on initialize, but you can have
    # an invariant.
    return if methodName.id2name == "initialize"

    # Lock us in:
    @@norecurse = true

    #
    # If we are defining an invariant, set things up.
    #
    if methodName.id2name == "invariant"

      klass.module_eval <<-EOF
        alias invariant__real invariant
        def invariant
          super
          raise InvariantException unless invariant__real 
        end
      EOF

      # Now we have to wrap every method in klass to check the invariant.
      invariantWrap(klass)

      @@norecurse = false
      return # We are done for now.
    end

    #
    # Not the invariant, check for pre/post conditions.
    #
    fileAndLine =~ /([^:]+):(\d+)/
    fileName = $1
    lineNum = ($2.to_i) -1

    
    pre_line = -1
    post_line = -1
    gotArgs= false

    source = SourceFile.new(fileName)
    while (line = source.line(lineNum)) != nil
      case line
        when /^\s*def\s+/ # Our method def, pick out the args
          break if gotArgs
          arglist = source.getArgsOn(lineNum)
          gotArgs = true
        when /^\s*pre\s*\{/  # Start of a precondition declaration
          pre_line = lineNum
        when /^\s*post\s*\{/  # Start of a precondition declaration
          post_line = lineNum
      end
      lineNum += 1
    end

    gotone = false
    me = klass.name + "." + methodName.id2name
    if klass.superclass.nil?
      dad = me # May as well make it circular
    else
      dad = klass.superclass.name + "." + methodName.id2name
    end

    # If there is a pre or a post, keep track of the affected method (for children)
    # and patch us in.
    if pre_line != -1 || post_line != -1 
        gotone = true
    end

    #
    # Special processing for "old" statements
    #
    saveOlds=[]
    count = 0

    if post_line != -1 
      post_assertion = source.getBlockOn(post_line)
      post_assertion.gsub!(/\s*old\s*\(([^\)]+)\)/) { |match|
        saveOlds << "Runtime[#{count}] = #{$1}"
        count += 1
        "Runtime[#{count-1}]"
      }
    end

    #
    # If we got a fresh pre/post condition, or if
    # a subclass defined one for this method,
    # then start wrapping.
    #
    if gotone || hasCondition(dad)

        # Child classes will have to know about us.
        saveCondition(me)
        myName = methodName.id2name

        #
        # This is the full method wrapper: ..................................
        #

        klass.module_eval <<-EOF
          alias #{xform(myName)} #{myName}
          def #{myName}(#{arglist})
            if !_dbc_guard(PRE)
              self._dbc_guard = true
              self.pre_#{myName}(#{arglist}) 
              self._dbc_guard = false
            end

            #{saveOlds.join("\n")}
            result = self.#{xform(myName)}(#{arglist})
            DbC::Runtime.result = result

            if !_dbc_guard(POST)
              self._dbc_guard = true
              self.post_#{myName}(#{arglist}) 
              self._dbc_guard = false
            end

            if !_dbc_guard(INV)
              self._dbc_guard = true
              invariant
              self._dbc_guard = false
            end

            result
          end
        EOF
        # ............................................................................................
    else
        if hasInvariant(klass)
          invariantWrap(klass)
        end
    end

    #
    # If we wrapped the main method,
    # we now need to create the actual
    # assertions.
    #
    if gotone
        if pre_line == -1 
          assertion = true
        else
          assertion = source.getBlockOn(pre_line)
        end

        #
        # Build the precondition
        #
        klass.module_eval <<-EOF
          def pre_#{methodName}(#{arglist})
             _dbc_block = proc { #{assertion}   }
             ret = false
             str = ""
             begin
              ret = _dbc_block.call()
             rescue
              ret = false
              str = $!
             end
             raise(PreConditionException.exception(str),caller[1]) unless ret
          end
        EOF

        if post_line == -1
          post_assertion = true
        end

        #
        # Build the postcondition
        #
        klass.module_eval <<-EOF
          def post_#{methodName}(#{arglist})
             if self.class.superclass.respond_to?("post_#{methodName}")
                super
             end
             _dbc_block = proc { #{post_assertion}   }
             ret = false
             str= ""
             begin
               ret = _dbc_block.call()
             rescue
               ret= false
               str = $!
             end
             raise(PostConditionException.exception(str),caller[1]) unless ret
          end
        EOF
    end

    # Undo the lock
    @@norecurse = false

  end

end # class dbc

end # end module

#
# This is the main trigger. As soon as a 
# new class is defined, we add a trigger on
# new methods added within that class.
#
def Object.inherited(subclass)

  subclass.module_eval <<-EOF
    def self.method_added(id)
      DbC::Runtime::parse(#{subclass.name},id,caller[0])
    end
  EOF
end

