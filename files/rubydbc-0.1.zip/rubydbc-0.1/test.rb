#
# $Id: test.rb,v 1.6 2001/02/20 04:12:58 andy Exp $
#
=begin

Test suite for DBC

Copyright (c) 2000 The Pragmatic Programmers, LLC. All Rights Reserved.
Author: Andrew Hunt (andy@pragmaticprogrammer.com)

=end

require 'runit/testcase'
require 'runit/cui/testrunner'
require 'dbc'

#
# First, we set up the test class and method definitions.
#

$test=1

class Foo
  def muggle
    pre {
      $test == 0
    }
    puts "Shouldn't be here"
  end

  def justAPost(a)
    post {
      DbC::Runtime.result < 10
    }
    return a/2
  end

  def usesOld(a)
    post {
      DbC::Runtime.result * 2 == old(a)
    }
    a = a/2
    return a
  end

  def auror
  end

  def muggleArgs(a, b, c)
    pre {
      (a == b && b == c)
    }
    a
  end

end

class Foo2 < Foo
  def wizard
  end

  def muggle
    puts "Shouldn't be here"
  end

  def muggleArgs(a, b, c)
    pre {
      (a < 10 && b < 10 && c < 10)
    }
    a
  end
end

class Always
  def initialize
    @depends = 50
  end

  def f1
    @depends = 40
    @depends = 50
  end

  def f2
    @depends = 40
  end

  def invariant
    @depends == 50
  end

end

class Always2
  def invariant
    @depends == 50
  end

  def initialize
    @depends = 50
  end

  def f1
    @depends = 40
    @depends = 50
  end

  def f2
    @depends = 40
  end
end

class OnTheFly
  def alpha(x)
    @var = x
    x
  end

  def beta
    true
  end
end

class Loopy
  def initialize
    @me = 50
  end
  def checkMe
    post { @me == 50 }
    @me
  end

  def invariant
    checkMe == 50
  end
end

class Setter
  def value=(foo)
    pre { foo < 10 }
  end
  def query?
    pre { false }
  end
end

###############################################################################
# Test class
###############################################################################
class DBCTest < RUNIT::TestCase

  def test_pre
    a = Foo.new
    assert_exception(PreConditionException) { a.muggle }
  end

  def test_pre_with_args
    a = Foo.new
    assert_equal(5, a.muggleArgs(5,5,5))
    assert_exception(PreConditionException) { a.muggleArgs(5,6,5) }
  end

  def test_pre_subclass
    a = Foo2.new
    assert_exception(PreConditionException) { a.muggle }
  end

  def test_pre_subclass_with_args
    a = Foo2.new
    assert_equal(5, a.muggleArgs(5,5,5))
    assert_exception(PreConditionException) { a.muggleArgs(5,16,5) }
  end

  def test_post_with_args
    a = Foo.new
    assert_equal(6,a.justAPost(12))
    assert_exception(PostConditionException) { a.justAPost(30) }
  end

  def test_post_with_old
    a = Foo.new
    assert_equal(6,a.usesOld(12))
    assert_exception(PostConditionException) { a.usesOld(13) }
  end

  def test_invariant
    a = Always.new
    a.f1
    assert_exception(InvariantException) { a.f2 }

    b = Always2.new
    b.f1
    assert_exception(InvariantException) { b.f2 }
  end

  def test_normal
    a=Foo.new
    a.auror
    b=Foo2.new
    b.wizard
  end

  def test_check
    check { true }
    assert_exception(CheckConditionException) { check { false } }
  end

  def not_on_the_fly # This doesn't work because you cannot use "eval" as a source.
    f = OnTheFly.new
    assert_equal(6, f.alpha(6))
    assert_equal(true, f.beta)

    OnTheFly.module_eval <<-EOF
      def alpha(x)
        pre { x > 10 }
        @var = x
        x
      end
      def invariant
        x == 50
      end
    EOF
    assert_exception(PreConditionException) { f.alpha(6) }
  end

  def test_loopy
    a = Loopy.new
    a.checkMe
  end

  def test_setter_pre
    a = Setter.new
    a.value = 8
    assert_exception(PreConditionException) { a.value = 99 }
    a = Setter.new
    assert_exception(PreConditionException) { a.query? }
  end


end # class test

RUNIT::CUI::TestRunner.run(DBCTest.suite)
