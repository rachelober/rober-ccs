#
# $Id: SourceFile.rb,v 1.4 2001/02/20 22:13:58 andy Exp $
#
=begin

Easy access and parsing to source code files.

Copyright (c) 2000 The Pragmatic Programmers, LLC. All Rights Reserved.
Author: Andrew Hunt (andy@pragmaticprogrammer.com)

=end

module DbC

class SourceFile

  private
#####################################################################
# Private Methods                                                   #
#####################################################################

#####################################################################
# Creation                                                          #
#####################################################################
  
  def initialize(fname)
    raise "Cannot use stdin as SourceFile" if fname == '-'
    raise "Cannot use eval as SourceFile" if fname == '(eval)'
    @filename =fname
    @lines = IO.readlines(fname) # Suck it in.
    @curLine = 0
    @curChar = 0
  end

  public
#####################################################################
# Command                                                           #
#####################################################################

  #
  # Return a copy of the indicated line in the file
  #
  def line(num)
    return nil if num >= @lines.length
    @curLine = num
    @curChar = 0
    @lines[num].dup
  end

  #
  # Return the next character from the file
  #
  def nextChar
    result = @lines[@curLine][@curChar,1]
    @curChar += 1
    if @curChar == @lines[@curLine].length
      @curChar = 0
      @curLine += 1
      if @curLine == @lines.length
        raise "End of source file reached while looking for block"
      end
    end

    result
  end

  #
  # Return a string containing the block that begins on the given line.
  #
  def getBlockOn(num)
    result = ""
    line(num) # Prime the pump
    c = nextChar while c != '{'
    depth = 0
    while c = nextChar
      break if c == '}' and depth == 0
      depth += 1 if c == '{'
      depth -= 1 if c == '}'
      result << c
    end
    result
  end

  #
  # Return a string containing the argument definition that begins on the given line.
  #
  def getArgsOn(num)
    result = ""
    s = line(num) # Prime the pump
    if !s.include?("(")
      return ""
    end
    c = nextChar while c != '('
    depth = 0
    while c = nextChar
      break if c == ')' and depth == 0
      depth += 1 if c == '('
      depth -= 1 if c == ')'
      result << c
    end
    result
  end

#####################################################################
# Queries                                                           #
#####################################################################

#####################################################################
# Properties                                                        #
#####################################################################

#####################################################################
# Testing                                                           #
#####################################################################

end # class SourceFile

end

# Self test
if $0 == __FILE__

  num = __LINE__; tester = proc {
    puts "Here"
  }

  sc = SourceFile.new(__FILE__)
  puts sc.getBlockOn(num-1)

end

