#
# $Id: blender.rb,v 1.5 2001/02/20 04:12:58 andy Exp $
#
=begin

Design By Contract "blender" example.
See "The Pragmatic Programmer", pages 119, 289, and 305.

Copyright (c) 2000 The Pragmatic Programmers, LLC. All Rights Reserved.
Author: Andrew Hunt (andy@pragmaticprogrammer.com)

=end

require 'dbc'

class Blender < Object

  private
#####################################################################
# Private Methods                                                   #
#####################################################################

#####################################################################
# Creation                                                          #
#####################################################################
  
  def initialize
    @full = false
    @speed = 0
  end

  public
#####################################################################
# Command                                                           #
#####################################################################
  def invariant
    implies(speed > 0, full?) &&
      (speed >= 0 && speed < 10)
  end

  def fill
    pre { !full? }
    post{ full? }
    @full = true
  end

  def empty
    pre { full? }
    post{ !full? }
    @full = false
  end


  def speed=(x)
    pre { 
      (speed - x).abs <= 1  && # Only change by 1
      x >= 0 && x < 10   # Range check on x
    }
    post { speed == x }
    @speed = x
  end

#####################################################################
# Queries                                                           #
#####################################################################

  def speed
    @speed
  end

  def full?
    @full
  end


end # class blender

DbC::Runtime.enable

b = Blender.new
b.fill
b.speed = 1
b.speed = 2
b.speed = 3
b.speed = 2
b.speed = 1
b.speed = 0
b.empty
puts "OK"

begin
  b.speed = 4
  b.fill
  b.fill
rescue
  puts "OK"
else
  puts "Should have had an exception..."
  exit 1
end

puts "Disabling DBC checks"
DbC::Runtime.enable(DbC::Runtime::NONE)

puts "now setting the speed"
b.speed = 8
b.speed = 11
b.empty
b.empty
b.fill
b.fill
b.speed = 0
b.speed = -12

puts "Re-enabling DBC checks"
DbC::Runtime.enable

# Need a new object to test, the old one is toast.
b = Blender.new

begin
  b.fill
  b.fill
rescue
  puts "OK (got exception #{$!.type})"
else
  puts "Should have had an exception..."
  exit 1
end

begin
  b = Blender.new
  puts "This should blow..."
  b.speed = 1000
rescue
  puts "OK"
else
  puts "Should have had an exception..."
end

