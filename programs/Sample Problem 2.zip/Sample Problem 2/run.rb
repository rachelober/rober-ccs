# run.rb
# This runs the test cases in the "tests" folder, and then prints the
# receipts to the screen.

# Required files
require 'tests/ts_sales_tax'
require 'lib/run_output'