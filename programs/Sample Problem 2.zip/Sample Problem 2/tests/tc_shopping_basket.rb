# tc_shopping_basket.rb
# Tests all methods from shopping_basket.rb
class TestShoppingBasket < Test::Unit::TestCase
  def setup
    @item_1_1 = Book.new(1, "book", 12.49, false)
    @item_1_2 = Good.new(1, "music CD", 14.99, false)
    @item_1_3 = Food.new(1, "chocolate bar", 0.85, false)
    @item_2_1 = Food.new(1, "imported box of chocolates", 10.00, true)
    @item_2_2 = Good.new(1, "imported bottle of perfume", 47.50, true)
    @item_3_1 = Good.new(1, "imported bottle of perfume", 27.99, true)
    @item_3_2 = Good.new(1, "bottle of perfume", 18.99, false)
    @item_3_3 = Medicine.new(1, "packet of headache pills", 9.75, false)
    @item_3_4 = Food.new(1, "box of imported chocolates", 11.25, true)
  end
  
  def test_add_good
    test_goods = [@item_1_1, @item_1_2, @item_1_3]
    shopping_basket_1 = Shopping_Basket.new(@item_1_1)
    shopping_basket_1.add_good(@item_1_2)
    shopping_basket_1.add_good(@item_1_3)
    assert_equal(test_goods, shopping_basket_1.goods)
  end
  
  def test_equal_huh?
  end
end