# file ts_sales_tax.rb
# This is the test suite for compute sales tax.

# Required files
require 'test/unit'
require 'lib/sales_tax/goods.rb'
require 'lib/sales_tax/shopping_basket.rb'

# Test Case Files
require 'tests/tc_goods'
require 'tests/tc_shopping_basket'
require 'tests/tc_compute_sales_tax'