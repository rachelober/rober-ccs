# ts_compute_sales_tax.rb
# Tests all methods from compute_sales_tax.rb
class TestShoppingBasket < Test::Unit::TestCase
  def setup
    @item_1_1 = Book.new(1, "book", 12.49, false)
    @item_1_2 = Good.new(1, "music CD", 14.99, false)
    @item_1_3 = Food.new(1, "chocolate bar", 0.85, false)
    @item_2_1 = Food.new(1, "imported box of chocolates", 10.00, true)
    @item_2_2 = Good.new(1, "imported bottle of perfume", 47.50, true)
    @item_3_1 = Good.new(1, "imported bottle of perfume", 27.99, true)
    @item_3_2 = Good.new(1, "bottle of perfume", 18.99, false)
    @item_3_3 = Medicine.new(1, "packet of headache pills", 9.75, false)
    @item_3_4 = Food.new(1, "box of imported chocolates", 11.25, true)
    
    @shopping_basket_1 = Shopping_Basket.new(@item_1_1)
    @shopping_basket_1.add_good(@item_1_2)
    @shopping_basket_1.add_good(@item_1_3)
    
    @shopping_basket_2 = Shopping_Basket.new(@item_2_1)
    @shopping_basket_2.add_good(@item_2_2)
    
    @shopping_basket_3 = Shopping_Basket.new(@item_3_1)
    @shopping_basket_3.add_good(@item_3_2)
    @shopping_basket_3.add_good(@item_3_3)
    @shopping_basket_3.add_good(@item_3_4)
  end
  
  def test_tally_up_full_price
    assert_in_delta(29.83, tally_up_full_price(@shopping_basket_1), 0.001)
    assert_in_delta(65.15, tally_up_full_price(@shopping_basket_2), 0.001)
    assert_in_delta(74.68, tally_up_full_price(@shopping_basket_3), 0.001)
  end
  
  def test_tally_up_tax
    assert_in_delta(1.50, tally_up_tax(@shopping_basket_1), 0.001)
    assert_in_delta(7.65, tally_up_tax(@shopping_basket_2), 0.001)
    assert_in_delta(6.70, tally_up_tax(@shopping_basket_3), 0.001)
  end
  
  def test_compute_full_price
    assert_in_delta(12.49, compute_full_price(@item_1_1), 0.001)
    assert_in_delta(16.49, compute_full_price(@item_1_2), 0.001)
    assert_in_delta(0.85, compute_full_price(@item_1_3), 0.001)
    assert_in_delta(10.50, compute_full_price(@item_2_1), 0.001)
    assert_in_delta(54.65, compute_full_price(@item_2_2), 0.001)
    assert_in_delta(32.19, compute_full_price(@item_3_1), 0.001)
    assert_in_delta(20.89, compute_full_price(@item_3_2), 0.001)
    assert_in_delta(9.75, compute_full_price(@item_3_3), 0.001)
    assert_in_delta(11.85, compute_full_price(@item_3_4), 0.001)
  end
  
  def test_compute_sales_tax
    assert_equal(0, compute_sales_tax(@item_1_1))
    assert_equal(BigDecimal('1.50'), compute_sales_tax(@item_1_2))
    assert_equal(0, compute_sales_tax(@item_1_3))
    assert_equal(BigDecimal('0.50'), compute_sales_tax(@item_2_1))
    assert_equal(BigDecimal('7.15'), compute_sales_tax(@item_2_2))
    assert_equal(BigDecimal('4.20'), compute_sales_tax(@item_3_1))
    assert_equal(BigDecimal('1.90'), compute_sales_tax(@item_3_2))
    assert_equal(0, compute_sales_tax(@item_3_3))
    assert_equal(BigDecimal('0.60'), compute_sales_tax(@item_3_4))
  end
  
  def test_round
    assert_equal(BigDecimal('10.00'), round(10.00))
    assert_equal(BigDecimal('10.05'), round(10.01))
    assert_equal(BigDecimal('10.05'), round(10.02))
    assert_equal(BigDecimal('10.05'), round(10.03))
    assert_equal(BigDecimal('10.05'), round(10.04))
    assert_equal(BigDecimal('10.05'), round(10.05))
    assert_equal(BigDecimal('10.10'), round(10.06))
    assert_equal(BigDecimal('10.10'), round(10.07))
    assert_equal(BigDecimal('10.10'), round(10.08))
    assert_equal(BigDecimal('10.10'), round(10.09))
  end
end