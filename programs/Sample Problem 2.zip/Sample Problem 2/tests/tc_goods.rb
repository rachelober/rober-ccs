# tc_goods.rb
# Tests all methods from goods.rb
class TestGoods < Test::Unit::TestCase
  def setup
    @item_1_1 = Book.new(1, "book", 12.49, false)
    @item_1_2 = Good.new(1, "music CD", 14.99, false)
    @item_1_3 = Food.new(1, "chocolate bar", 0.85, false)
    @item_2_1 = Food.new(1, "imported box of chocolates", 10.00, true)
    @item_2_2 = Good.new(1, "imported bottle of perfume", 47.50, true)
    @item_3_1 = Good.new(1, "imported bottle of perfume", 27.99, true)
    @item_3_2 = Good.new(1, "bottle of perfume", 18.99, false)
    @item_3_3 = Medicine.new(1, "packet of headache pills", 9.75, false)
    @item_3_4 = Food.new(1, "box of imported chocolates", 11.25, true)
  end
  
  def test_quantity_check
    assert_raise(ArgumentError){Book.new(-345, "book", 12.49, false)}
    assert_nothing_raised(ArgumentError){Book.new(2, "book", 12.49, false)}
  end
  
  def test_price_check
    assert_raise(ArgumentError){Book.new(1, "book", -345, false)}
    assert_nothing_raised(ArgumentError){Book.new(1, "book", 12.49, false)}
  end
  
  def test_item_name_check
    assert_raise(ArgumentError){Book.new(1, nil, 12.49, false)}
    assert_nothing_raised(ArgumentError){Book.new(1, "book", 12.49, false)}
  end
  
  def test_imported_check
    assert_raise(ArgumentError){Book.new(1, "book", 12.49, "foo")}
    assert_nothing_raised(ArgumentError){Book.new(1, "book", 12.49, false)}
  end
  
  def test_same
    test_good = Good.new(1, "imported bottle of perfume", 47.50, true)
    assert_same(test_good, @item_2_2)
    assert_not_same(@item_2_2, @item_1_1)
  end
  
  def test_quantity
    assert_equal(1, @item_1_1.quantity)
    assert_equal(1, @item_1_2.quantity)
    assert_equal(1, @item_1_3.quantity)
    assert_equal(1, @item_2_1.quantity)
    assert_equal(1, @item_2_2.quantity)
    assert_equal(1, @item_3_1.quantity)
    assert_equal(1, @item_3_2.quantity)
    assert_equal(1, @item_3_3.quantity)
    assert_equal(1, @item_3_4.quantity)
  end
  
  def test_price
    assert_equal(12.49, @item_1_1.price)
    assert_equal(14.99, @item_1_2.price)
    assert_equal(0.85, @item_1_3.price)
    assert_equal(10.00, @item_2_1.price)
    assert_equal(47.50, @item_2_2.price)
    assert_equal(27.99, @item_3_1.price)
    assert_equal(18.99, @item_3_2.price)
    assert_equal(9.75, @item_3_3.price)
    assert_equal(11.25, @item_3_4.price)
  end
  
  def test_item_name
    assert_equal("book", @item_1_1.item_name)
    assert_equal("music CD", @item_1_2.item_name)
    assert_equal("chocolate bar", @item_1_3.item_name)
    assert_equal("imported box of chocolates", @item_2_1.item_name)
    assert_equal("imported bottle of perfume", @item_2_2.item_name)
    assert_equal("imported bottle of perfume", @item_3_1.item_name)
    assert_equal("bottle of perfume", @item_3_2.item_name)
    assert_equal("packet of headache pills", @item_3_3.item_name)
    assert_equal("box of imported chocolates", @item_3_4.item_name)
  end
  
  def test_imported_huh
    assert(!@item_1_1.imported?)
    assert(!@item_1_2.imported?)
    assert(!@item_1_3.imported?)
    assert(@item_2_1.imported?)
    assert(@item_2_2.imported?)
    assert(@item_3_1.imported?)
    assert(!@item_3_2.imported?)
    assert(!@item_3_3.imported?)
    assert(@item_3_4.imported?)
  end

  def test_book_huh
    assert(@item_1_1.book?)
    assert(!@item_1_2.book?)
    assert(!@item_1_3.book?)
    assert(!@item_2_1.book?)
    assert(!@item_2_2.book?)
    assert(!@item_3_1.book?)
    assert(!@item_3_2.book?)
    assert(!@item_3_3.book?)
    assert(!@item_3_4.book?)
  end
  
  def test_food_huh
    assert(!@item_1_1.food?)
    assert(!@item_1_2.food?)
    assert(@item_1_3.food?)
    assert(@item_2_1.food?)
    assert(!@item_2_2.food?)
    assert(!@item_3_1.food?)
    assert(!@item_3_2.food?)
    assert(!@item_3_3.food?)
    assert(@item_3_4.food?)
  end
  
  def test_medicine_huh
    assert(!@item_1_1.medicine?)
    assert(!@item_1_2.medicine?)
    assert(!@item_1_3.medicine?)
    assert(!@item_2_1.medicine?)
    assert(!@item_2_2.medicine?)
    assert(!@item_3_1.medicine?)
    assert(!@item_3_2.medicine?)
    assert(@item_3_3.medicine?)
    assert(!@item_3_4.medicine?)
  end
end