# good.rb
# This file constructs the class Good and the subclasses
# Book, Food, and Medicine.
module ComputeSalesTax
  # This class will create a good that includes a price 
  # and a sales tax rate and whether it is imported or not.
  class Good
    include Comparable
    attr_reader :quantity, :item_name, :price, :tax_rate
  
    # initialize : Integer String Float Boolean -> Good
    # Create a new Object of type Good.
    # Delegates to the setter methods instead of setting
    # them here so we can enforce rules.
    def initialize(quantity, item_name, price, imported)
      self.quantity = quantity                  # Integer
      self.item_name = item_name                # String
      self.price = price                        # BigDecimal
      self.imported = imported                  # Boolean
      @tax_rate = 0.10                          # Float
    end
  
    # imported? : -> Boolean
    # Is this Good imported?
    def imported?
      return @imported
    end

    # book? : Good -> Boolean
    # Is this Good a Book?
    def book?
      false
    end
  
    # food? : Good -> Boolean
    # Is this Good a Food?
    def food?
      false
    end
  
    # medicine? : Good -> Boolean
    # Is this Good a Medicine?
    def medicine?
      false
    end
    
    # equal? : Good -> Boolean
    # Is this Good equal to the other Good?
    def equal?(good)
      good.instance_of?(Good) && 
      @quantity == good.quantity &&
      @item_name == good.item_name &&
      @price == good.price &&
      @imported == good.imported?
    end
  
    private
    # When trying to set "quantity", enforce rules.
    # "Quantity" must be a positive number.
    def quantity=(quantity)
      if quantity <= 0
        raise ArgumentError.new('Quantity must be more than zero.')
      end
      @quantity = quantity
    end
  
    # When trying to set "price", enforce rules.
    # "Price" must be a positive number.
    def price=(price)
      if price <= 0
        raise ArgumentError.new('Price must be more than zero.')
      end
      @price = price
    end
  
    # When trying to set "item_name", enforce rules.
    # "item_name" must not be blank.
    def item_name=(item_name)
      if (item_name == nil or item_name.size == 0)
        raise ArgumentError.new('Good must have a name.')
      end
      @item_name = item_name
    end
  
    # When trying to set "imported", enforce rules.
    # "Imported" must be a Boolean.
    def imported=(imported)
      if !(imported.kind_of?(FalseClass) || imported.kind_of?(TrueClass))
        raise ArgumentError.new('Imported must be a Boolean.')
      end
      @imported = imported
    end
  end

  # Class information for a Book Good.
  # Currently nothing outstanding besides not having
  # any sales tax (unless imported).
  class Book < Good
    # initialize : Integer String Float Boolean -> Book
    # Create a new Object of type Book.
    def initialize(quantity, item_name, price, imported)
      super(quantity, item_name, price, imported)
      @tax_rate = 0.00   # Float
    end

    # book? : Good -> Boolean
    # Is this Good a Book?
    def book?
      true
    end
  
    # equal? : Book -> Boolean
    # Is this Book equal to the other Book?
    def equal?(good)
      good.instance_of?(Book) && 
      @quantity == good.quantity &&
      @item_name == good.item_name &&
      @price == good.price &&
      @imported == good.imported?
    end
  end

  # Class information for a Food Good.
  # Currently nothing outstanding besides not having
  # any sales tax (unless imported).
  class Food < Good
    # initialize : Integer String Float Boolean -> Food
    # Create a new Object of type Food.
    def initialize(quantity, item_name, price, imported)
      super(quantity, item_name, price, imported)
      @tax_rate = 0.00   # Float
    end

    # food? : Food -> Boolean
    # Is this Good a Food?
    def food?
      true
    end
  
    # equal? : Food -> Boolean
    # Is this Food equal to the other Food?
    def equal?(good)
      good.instance_of?(Food) && 
      @quantity == good.quantity &&
      @item_name == good.item_name &&
      @price == good.price &&
      @imported == good.imported?
    end
  end

  # Class information for a Medicine Good.
  # Currently nothing outstanding besides not having
  # any sales tax (unless imported).
  class Medicine < Good
    # initialize : Integer String Float Boolean -> Medicine
    # Create a new Object of type Medicine.
    def initialize(quantity, item_name, price, imported)
      super(quantity, item_name, price, imported)
      @tax_rate = 0.00   # Float
    end

    # medicine? : Medicine -> Boolean
    # Is this Good a Medicine?
    def medicine?
      true
    end
  
    # equal? : Medicine -> Boolean
    # Is this Medicine equal to the other Medicine?
    def equal?(good)
      good.instance_of?(Medicine) && 
      @quantity == good.quantity &&
      @item_name == good.item_name &&
      @price == good.price &&
      @imported == good.imported?
    end
  end
end