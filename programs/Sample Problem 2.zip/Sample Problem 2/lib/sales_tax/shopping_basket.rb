# shopping_basket.rb
# The shopping basket is where we keep all our Goods.
module ComputeSalesTax
  class Shopping_Basket
    include Comparable
    attr_reader :goods
  
    # initialize : Good -> Array of Goods
    # This object takes a single Good. Goods can be
    # added to the Shopping Basket with the "add_good"
    # method.  
    def initialize(good)
      @goods = Array.new([good])  # Array of Goods
    end
  
    # add_good : Good -> Array of Goods
    # Adds a Good to the Shopping Basket.
    def add_good(good)
      @goods.push(good)
    end
  
    private
    # Comparable method for comparing shopping baskets.
    def <=>(other)
      @goods <=> other.goods
    end
  end
end