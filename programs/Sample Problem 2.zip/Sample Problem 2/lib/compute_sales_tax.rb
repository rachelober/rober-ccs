# compute_sales_tax.rb
# Rachel A Ober
# rober@ccs.neu.edu
# Code to compute sales tax of imported and non-imported items.
require "bigdecimal"
require "bigdecimal/math"
require "lib/sales_tax/goods.rb"
require "lib/sales_tax/shopping_basket.rb"
include BigMath
include ComputeSalesTax

# This module includes the method to print the receipt
# to the screen. It lists all the items in the Shopping Basket
# (in order) with their totals + tax, the final tax, and then
# the total money spent.
module ComputeSalesTax
  # print_receipt : shopping_list ->
  # This method takes a shopping list and iterates through
  # the list, looking at goods and computing
  # prices to print out on the receipt in the proper format.
  def print_receipt(shopping_basket)
    shopping_basket.goods.each do |good| 
      print "#{good.quantity} #{good.item_name}: "
      printf('%.02f', compute_full_price(good))
      print "\n"
    end
    
    print "Sales Taxes: "
    printf('%.02f', tally_up_tax(shopping_basket))
    print "\nTotal: "
    printf('%.02f', tally_up_full_price(shopping_basket))
    print "\n"
  end
  
  private
  # tally_up_full_price : Shopping_Basket -> Float
  # Adds up the Shopping Basket full item total
  # (which includes tax).
  def tally_up_full_price(shopping_basket)
    full_price = 0
    shopping_basket.goods.each do |good| 
      full_price += compute_full_price(good)
    end
    return full_price
  end
  
  # tally_up_tax : Shopping_Basket -> Float
  # Adds up the tax on all items in the Shopping Basket.
  def tally_up_tax(shopping_basket)
    sales_tax = 0
    shopping_basket.goods.each do |good| 
      sales_tax += compute_sales_tax(good)
    end
    sales_tax
  end
  
  # compute_full_price : Good -> Float
  # Adds the price to the computed sales tax.
  def compute_full_price(good)
    return good.price + compute_sales_tax(good)
  end
  
  # compute_sales_tax : Good -> BigDecimal
  # Computes the appropriate sales tax after
  # taking into consideration the sales tax
  # of the good and if it also includes
  # an imported sales tax.
  def compute_sales_tax(good)
    sales_tax = good.price * good.tax_rate
    price = good.price
    
    if good.imported?
      sales_tax += price * 0.05
    end
    
    return round(sales_tax)
  end
  
  # round : Number -> BigDecimal
  # Rounds the tax so that it has a precision of 2
  # and rounds up as necessary to the closest 0.05%.
  def round(price)
    amount = BigDecimal.new(price.to_s)
    rounded = (amount * 100).round
    if (rounded % 5 >= 1) && (rounded % 5 <= 4)
      rounded += 5 - (rounded % 5)
    end
    return rounded / 100
  end
end