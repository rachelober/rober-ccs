# run_output.rb
# This is just to test run the output of all the given
# test cases.
require "lib/compute_sales_tax.rb"

begin
  puts "OUTPUT"
  
  # Print Output 1
  item_1_1 = Book.new(1, "book", 12.49, false)
  item_1_2 = Good.new(1, "music CD", 14.99, false)
  item_1_3 = Food.new(1, "chocolate bar", 0.85, false)
  shopping_basket_1 = Shopping_Basket.new(item_1_1)
  shopping_basket_1.add_good(item_1_2)
  shopping_basket_1.add_good(item_1_3)
  puts "\nOutput 1:"
  print_receipt(shopping_basket_1)
  
  # Print Output 2
  item_2_1 = Food.new(1, "imported box of chocolates", 10.00, true)
  item_2_2 = Good.new(1, "imported bottle of perfume", 47.50, true)
  shopping_basket_2 = Shopping_Basket.new(item_2_1)
  shopping_basket_2.add_good(item_2_2)
  puts "\nOutput 2:"
  print_receipt(shopping_basket_2)
  
  # Print Output 3
  item_3_1 = Good.new(1, "imported bottle of perfume", 27.99, true)
  item_3_2 = Good.new(1, "bottle of perfume", 18.99, false)
  item_3_3 = Medicine.new(1, "packet of headache pills", 9.75, false)
  item_3_4 = Food.new(1, "box of imported chocolates", 11.25, true)
  shopping_basket_3 = Shopping_Basket.new(item_3_1)
  shopping_basket_3.add_good(item_3_2)
  shopping_basket_3.add_good(item_3_3)
  shopping_basket_3.add_good(item_3_4)
  puts "\nOutput 3:"
  print_receipt(shopping_basket_3)
end